// Variáveis para armazenar o estado da gravação
let mediaRecorder = null;
let audioChunks = [];
let audioStream = null;
let audioBlob = null;
let audioFile = null;
let recordingIndicator = null;
let recordButton = null;
let isRecording = false;

// Função para criar o indicador de gravação
function createRecordingIndicator() {
  // Remove o indicador anterior se existir
  if (recordingIndicator) {
    recordingIndicator.remove();
  }

  // Adiciona o link para o Material Icons
  const link = document.createElement('link');
  link.href = 'https://fonts.googleapis.com/icon?family=Material+Icons';
  link.rel = 'stylesheet';
  document.head.appendChild(link);

  // Cria o elemento do indicador
  recordingIndicator = document.createElement('div');
  recordingIndicator.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: rgba(244, 67, 54, 0.9);
    color: white;
    padding: 8px 16px;
    border-radius: 20px;
    font-family: Arial, sans-serif;
    font-size: 14px;
    z-index: 9999;
    display: flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
  `;

  // Adiciona o ícone de gravação
  const recordingIcon = document.createElement('span');
  recordingIcon.className = 'material-icons';
  recordingIcon.textContent = 'mic';
  recordingIcon.style.cssText = `
    animation: pulse 1s infinite;
  `;

  // Adiciona a animação de pulso
  const style = document.createElement('style');
  style.textContent = `
    @keyframes pulse {
      0% { opacity: 1; }
      50% { opacity: 0.5; }
      100% { opacity: 1; }
    }
  `;
  document.head.appendChild(style);

  // Adiciona o texto
  const text = document.createElement('span');
  text.textContent = 'Gravando...';
  
  // Monta o indicador
  recordingIndicator.appendChild(recordingIcon);
  recordingIndicator.appendChild(text);
  document.body.appendChild(recordingIndicator);
}

// Função para atualizar o indicador
function updateRecordingIndicator(isRecording) {
  if (!recordingIndicator) {
    createRecordingIndicator();
  }

  if (isRecording) {
    recordingIndicator.style.display = 'flex';
  } else {
    recordingIndicator.style.display = 'none';
  }
}

// Função para criar e injetar o botão de gravação
function injectRecordButton() {
  // Procura pelo botão de template do 3CX
  const templateButton = document.querySelector('button#templateSelector');
  
  if (!templateButton) {
    console.log('Botão de template não encontrado, tentando novamente em 1 segundo...');
    setTimeout(injectRecordButton, 1000);
    return;
  }

  // Cria o botão de gravação
  recordButton = document.createElement('button');
  recordButton.type = 'button';
  recordButton.className = 'btn btn-plain';
  recordButton.innerHTML = `
    <span class="record-icon">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" width="16" height="16">
        <path fill="currentColor" d="M192 0C139 0 96 43 96 96V256c0 53 43 96 96 96s96-43 96-96V96c0-53-43-96-96-96zM64 216c0-13.3-10.7-24-24-24s-24 10.7-24 24v40c0 89.1 66.2 162.7 152 174.4V464H120c-13.3 0-24 10.7-24 24s10.7 24 24 24h72 72c13.3 0 24-10.7 24-24s-10.7-24-24-24H216V430.4c85.8-11.7 152-85.3 152-174.4V216c0-13.3-10.7-24-24-24s-24 10.7-24 24v40c0 70.7-57.3 128-128 128s-128-57.3-128-128V216z"/>
      </svg>
    </span>
    <span class="button-text">Gravar Áudio</span>
  `;

  // Adiciona estilos
  const style = document.createElement('style');
  style.textContent = `
    .record-icon {
      display: inline-flex;
      align-items: center;
      margin-right: 4px;
    }
    .record-icon svg {
      width: 16px;
      height: 16px;
    }
    .recording .record-icon {
      color: #f44336;
      animation: pulse 1s infinite;
    }
    @keyframes pulse {
      0% { opacity: 1; }
      50% { opacity: 0.5; }
      100% { opacity: 1; }
    }
  `;
  document.head.appendChild(style);

  // Adiciona o event listener
  recordButton.addEventListener('click', async () => {
    if (!isRecording) {
      try {
        const result = await startRecording();
        if (result.success) {
          isRecording = true;
          recordButton.classList.add('recording');
          recordButton.querySelector('.button-text').textContent = 'Parar Gravação';
        }
      } catch (error) {
        console.error('Erro ao iniciar gravação:', error);
      }
    } else {
      try {
        const result = await stopRecording();
        if (result.success) {
          isRecording = false;
          recordButton.classList.remove('recording');
          recordButton.querySelector('.button-text').textContent = 'Gravar Áudio';
        }
      } catch (error) {
        console.error('Erro ao parar gravação:', error);
      }
    }
  });

  // Insere o botão após o botão de template
  templateButton.parentNode.insertBefore(recordButton, templateButton.nextSibling);
}

// Inicia a injeção do botão quando o DOM estiver pronto
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectRecordButton);
} else {
  injectRecordButton();
}

// Função para iniciar a gravação
async function startRecording() {
  try {
    // Solicita acesso ao microfone
    audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    
    // Cria uma nova instância do MediaRecorder
    mediaRecorder = new MediaRecorder(audioStream);
    
    // Limpa os chunks anteriores
    audioChunks = [];
    
    // Configura o evento para coletar os dados de áudio
    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        audioChunks.push(event.data);
      }
    };
    
    // Configura o evento para quando a gravação parar
    mediaRecorder.onstop = () => {
      // Cria um Blob com os chunks de áudio
      audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
      console.log('Gravação finalizada. Tamanho do áudio:', audioBlob.size);
      
      // Cria um objeto File a partir do Blob
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      audioFile = new File([audioBlob], `audio_message_${timestamp}.webm`, {
        type: 'audio/webm',
        lastModified: Date.now()
      });
      console.log('Arquivo de áudio criado:', audioFile.name, 'Tamanho:', audioFile.size);
      
      // Para todas as tracks do stream
      audioStream.getTracks().forEach(track => track.stop());
      
      // Atualiza o indicador
      updateRecordingIndicator(false);
    };
    
    // Inicia a gravação
    mediaRecorder.start();
    console.log('Gravação iniciada');
    
    // Mostra o indicador
    updateRecordingIndicator(true);
    
    return { success: true };
  } catch (error) {
    console.error('Erro ao iniciar gravação:', error);
    
    // Atualiza o indicador em caso de erro
    updateRecordingIndicator(false);
    
    // Tratamento específico para erro de permissão
    if (error.name === 'NotAllowedError') {
      return { 
        success: false, 
        error: 'Permissão para acessar o microfone foi negada' 
      };
    }
    
    return { 
      success: false, 
      error: 'Erro ao iniciar gravação: ' + error.message 
    };
  }
}

// Função para parar a gravação
async function stopRecording() {
  try {
    if (!mediaRecorder || mediaRecorder.state === 'inactive') {
      return { 
        success: false, 
        error: 'Nenhuma gravação em andamento' 
      };
    }
    
    // Para a gravação
    mediaRecorder.stop();
    console.log('Parando gravação...');
    
    // Atualiza o indicador
    updateRecordingIndicator(false);
    
    return { success: true };
  } catch (error) {
    console.error('Erro ao parar gravação:', error);
    return { 
      success: false, 
      error: 'Erro ao parar gravação: ' + error.message 
    };
  }
}

// Listener para mensagens do background script
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Mensagem recebida:', message);
  
  // Processa o comando recebido
  switch (message.command) {
    case 'start_recording':
      startRecording()
        .then(response => sendResponse(response))
        .catch(error => sendResponse({ 
          success: false, 
          error: 'Erro ao iniciar gravação: ' + error.message 
        }));
      break;
      
    case 'stop_recording':
      stopRecording()
        .then(response => sendResponse(response))
        .catch(error => sendResponse({ 
          success: false, 
          error: 'Erro ao parar gravação: ' + error.message 
        }));
      break;
      
    default:
      sendResponse({ 
        success: false, 
        error: 'Comando desconhecido: ' + message.command 
      });
  }
  
  // Retorna true para indicar que a resposta será assíncrona
  return true;
}); 